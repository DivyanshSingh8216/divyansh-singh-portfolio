# MASTER PROMPT — DIVYANSH SINGH PERSONAL PORTFOLIO

Create a premium, modern, visually impressive **static portfolio website for Divyansh Singh** using **all relevant saved information, photos, documents, project files, certificates, screenshots, and existing project assets available in the provided workspace/context**.

The website should feel like a **professional personal brand website**, not a student template.

---

# 1. IMPORTANT — USE MY SAVED ASSETS

Before building the website, inspect the available saved files and assets.

Look specifically for:

- My profile photographs
- Resume
- Project documentation
- Project screenshots
- Certificates
- Internship certificates
- Project ZIP/files
- Website screenshots
- Logos
- Existing project images
- GitHub/project information
- Presentation files
- Training certificates
- Relevant documents containing project descriptions
- Any previously uploaded portfolio-related assets

### Asset rule

**Reuse my actual saved assets wherever relevant.**

Do NOT replace available real assets with:

- Generic stock photos
- Random AI-generated people
- Generic developer illustrations
- Fake project screenshots
- Fake certificates
- Fake company logos

If a relevant real asset exists, prioritize it.

---

# 2. CREATE AN ASSET LIBRARY

Organize the assets inside the project.

For example:

```text
/public
   /images
      profile/
      projects/
      certificates/
      experience/
      branding/

```

Rename files clearly when necessary.

Examples:

```text
profile-photo.jpg
infraconn-home.png
infraconn-dashboard.png
aws-certificate.png
data-analytics-certificate.png

```

Do not delete or modify the original files unnecessarily.

---

# 3. PROFILE PHOTO

If an actual professional photograph of Divyansh Singh exists:

Use it prominently in the portfolio.

Possible locations:

- Hero section
- About section
- Small profile element in navbar
- Contact section

Do not use the photograph everywhere.

Create a premium treatment around the image.

For example:

**Profile photo + subtle gradient ring + technical grid + DS monogram**

Do not heavily edit or distort the photograph.

---

# 4. HERO SECTION

Create a visually powerful hero section.

### Left

Large heading:

**DIVYANSH SINGH**

Subtitle:

**Technology × Data × AI × Business**

Add a concise introduction based on my saved profile.

Buttons:

**Explore My Work**

**Let's Connect**

### Right

Use my actual profile photograph if available.

Combine it with custom graphical elements:

- Data nodes
- Fine grid
- Digital particles
- Geometric shapes
- Circular rings
- Connecting lines

The graphics should complement the photograph rather than cover it.

---

# 5. ABOUT SECTION

Use my actual photograph again only if it improves the composition.

Combine:

### About Me

with:

### What I Work Across

**Software Development**
**Data & Analytics**
**AI / Machine Learning**
**Cloud / AWS**
**Business Development**
**Growth & Leadership**

Use icons and subtle graphics.

The section should visually communicate that I am not limited to one domain.

---

# 6. PROJECTS — USE ACTUAL PROJECT FILES

This is extremely important.

Inspect my saved project files and documentation.

For each project that has actual screenshots or visual assets:

**Use those screenshots in the portfolio.**

Do not create fake screenshots.

For example, for **InfraConn**, inspect the saved project/code/files and use available:

- Homepage screenshots
- Dashboard screenshots
- UI screens
- Service pages
- Portfolio screens
- Relevant architecture visuals

Create a large featured project presentation.

---

# 7. INFRAConn FEATURED PROJECT

Make **InfraConn** the primary featured project if the saved project assets support it.

Layout:

```text
------------------------------------------------
|                                              |
|                PROJECT IMAGE                |
|                                              |
------------------------------------------------

INFRAConn
Connect & Build

Construction-services marketplace/platform.

[ Laravel ] [ PHP ] [ Livewire ] [ Tailwind ]

                         Explore Project →

```

Use actual screenshots from the project.

Add a subtle construction-inspired graphic overlay:

- Blueprint grid
- Building geometry
- Connection nodes
- Architectural lines

Do NOT make it look like a construction company website.

It should still look like a technology product.

---

# 8. OTHER PROJECTS

Search the saved files for additional genuine projects.

Potential categories include:

- Data Analytics
- AWS Data Engineering
- Machine Learning
- AI
- Tourism
- IoT
- Startup projects

Only include projects supported by actual saved information.

Each project should have:

- Actual project image/screenshot if available
- Project name
- Description
- Problem solved
- Technologies
- Key features
- GitHub/demo link if available

---

# 9. CERTIFICATES

Use my actual saved certificate images/PDFs.

Create a visually attractive certification section.

Instead of displaying every certificate immediately, create cards.

Each card:

**Certificate Preview**

Certificate name

Organization

Year

**View Certificate →**

When clicked, open the full certificate in a modal/lightbox or dedicated view.

Do not fabricate certificate information.

---

# 10. RESUME

Use the saved resume/document as a source of truth for:

- Education
- Experience
- Skills
- Projects
- Certifications
- Roles
- Contact information

Do not blindly copy the resume.

Convert the information into polished website content.

Add:

**Download Resume**

only if an actual resume file is available.

Use the actual file.

---

# 11. EXPERIENCE

Use the saved professional information and documents.

Create a visual timeline.

For each role:

**Organization**

**Position**

**Duration**

Short description.

Use company logos only when real logos are available.

If no logo is available, use a clean text-based organization mark.

Do not invent logos.

---

# 12. CERTIFICATE / DOCUMENT VISUALS

For PDFs that contain important visual information:

Extract or display the relevant page as an image when appropriate.

For example:

- Internship certificate
- Training certificate
- Project certificate
- Relevant project documentation

Make these visually browsable.

Use:

**Preview → View Full Document**

---

# 13. GRAPHICS SYSTEM

Create custom graphics around my real assets.

Visual language:

**Dark + premium + technical + minimal**

Use:

- Thin grids
- Network nodes
- Data points
- Gradient glows
- Geometric lines
- Abstract charts
- Digital particles
- Blueprint patterns
- Soft glass cards

Graphics should support my actual content.

Do not overwhelm photographs, certificates, or screenshots.

---

# 14. PROJECT VISUALIZATION

Different projects should have different visual identities.

### Software Projects

Use:

- UI screenshots
- Code-inspired patterns
- Interface grids

### Data Projects

Use:

- Charts
- Graphs
- Data points
- Analytical patterns

### AI Projects

Use:

- Neural-network-inspired nodes
- Connected points
- Abstract intelligence patterns

### AWS/Data Engineering

Use:

- Cloud architecture-inspired graphics
- Data pipelines
- Nodes and connections

### InfraConn

Use:

- Blueprint-inspired grid
- Construction geometry
- Professional connection network

---

# 15. IMAGE PRESENTATION

Do not simply place images inside rectangular boxes.

Use:

- Rounded corners
- Layered cards
- Floating image effects
- Subtle shadows
- Image masks where appropriate
- Hover zoom
- Lightbox previews

However, keep the design professional.

---

# 16. INTERACTIVE PROJECT GALLERY

Create a project gallery where clicking a project opens a larger view.

Example:

```text
Project
   ↓
Project Preview
   ↓
Gallery
   ↓
Description
   ↓
Technology Stack
   ↓
GitHub / Demo

```

Use actual screenshots from the saved files.

---

# 17. VISUAL TIMELINE

Create an animated timeline connecting:

**Education → Experience → Projects → Leadership**

Use subtle animated lines.

Each point can expand into a card.

Do not use excessive animation.

---

# 18. PERSONAL BRAND

Create a simple **DS** monogram from:

**Divyansh Singh**

Use it consistently.

Possible locations:

- Navbar
- Favicon
- Footer
- Loading screen
- Small graphic elements

---

# 19. NAVIGATION

Navbar:

**DS | Divyansh Singh**

Links:

- Home
- About
- Experience
- Projects
- Certifications
- Contact

Add:

**Download Resume**

if the real resume file exists.

---

# 20. HOMEPAGE FLOW

Use this visual sequence:

### HERO

Profile + identity + custom graphics

↓

### QUICK INTRO

Who I am

↓

### EXPERTISE

Technology / Data / AI / Business

↓

### FEATURED PROJECT

InfraConn

↓

### OTHER PROJECTS

Project gallery

↓

### EXPERIENCE

Timeline

↓

### CERTIFICATIONS

Real certificate previews

↓

### LEADERSHIP

Professional + extracurricular experience

↓

### CONTACT

Let's build something meaningful.

---

# 21. DESIGN QUALITY

The website should have:

- Premium typography
- Strong spacing
- High-quality imagery
- Smooth transitions
- Subtle hover effects
- Scroll animations
- Responsive layouts
- Beautiful project cards
- Consistent iconography
- Excellent mobile design

Avoid:

- Generic Bootstrap layouts
- Overused glassmorphism
- Excessive neon
- Excessive gradients
- Giant unnecessary animations
- Stock photos
- Fake testimonials
- Fake statistics
- Fake logos
- Fake projects

---

# 22. RESPONSIVE BEHAVIOR

Desktop:

Use large visuals and split layouts.

Tablet:

Reduce spacing and image sizes.

Mobile:

Stack sections vertically.

Make sure:

- Images remain visible
- Text remains readable
- Cards don't overflow
- Navigation becomes a mobile menu
- Complex background animations are reduced
- No horizontal scrolling occurs

---

# 23. STATIC WEBSITE

Keep the website static.

Preferred stack:

**React + Vite + Tailwind CSS**

Use reusable components.

Suggested structure:

```text
src/
  components/
    Navbar
    Hero
    About
    Skills
    Experience
    Projects
    ProjectCard
    Certifications
    Contact
    Footer

  pages/
    Home
    About
    Projects
    Contact

```

Use local assets rather than unnecessary external APIs.

---

# 24. CONTENT ACCURACY

The saved files and information are the source of truth.

If there is a conflict between generated content and a saved document:

**Trust the saved document.**

Do not invent:

- Experience
- Dates
- Companies
- Technologies
- Projects
- Awards
- Statistics
- Certificate details
- Links

If information is unavailable, omit it.

---

# 25. FINAL EXPERIENCE

The final website should feel like:

**A personal technology brand built around a real person and real work.**

The viewer should see:

**Divyansh Singh**

and immediately understand:

> Computer Science + Technology + Data + AI + Business + Leadership

The website should make my **real photos, projects, certificates, and work the centerpiece**, while the graphics and animations enhance those assets rather than replacing them.

Most importantly:

**Use my actual saved files wherever possible. Do not create generic substitutes when authentic assets are available.**